package negevVer3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;

import negevVer3.SoilType.Type;

import com.vividsolutions.jts.geom.Geometry;

import repast.simphony.context.Context;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.gis.Geography;
import repast.simphony.util.ContextUtils;
import sun.dc.pr.PRException;

public class AgriculturalLandParcel {
	
	public enum Status{
		VIRGIN,		//not claimed - currently not in use - by Default a parcel belongs to a Settlement
		SETTLEMENT_CLAIMED,		//belongs to a specific settlement � not yet cultivated 
		FARMER_CLAIMED,		//belongs to a specific farmer � not yet cultivated 
		CULTIVATED,		//the field is currently used for cropping 
		FALLOW		//the field is currently in fallow /rest 		
	}

	Status status;
	FarmerAgent owner;
	Crop currentCrop;
//	Crop nextCrop;
	Crop prevYearCrop;
	Crop prev2YearCrop;
	Crop prev3YearCrop;
	Crop prev4YearCrop;
	double currentWheatYieldForFarmer = 0;
	double currentWheatYieldForGrazing = 0;
	double currentStrawWheatYield = 0;
//	static final List <String> cropCycle = Arrays.asList("COTTON" , "CEREAL" , "CEREAL"); // The crop cycle is: cotton-cereal-cereal
	static final List <String> cropCycleRainfed = Arrays.asList("Wheat" , "Wheat" , "Legume"); // The crop cycle is: Wheat-Wheat-Pea
	static final List <String> cropCycleIrrigated = Arrays.asList("Potato" , "Wheat" , "Veg", "Wheat" , "Wheat"); // Veg can be any irrigated vegetable that isn't potato
	double SOM;
	double area; //agricultural parcel's area in m^2
	int cycleCount;  //year 0-2 within the cropCycleRainfed and 0-4 for cropCycleIrrigated
	Settlement settlement;
	int initialCropType = -1, irrigationScheme = -1, settId = -1, cropClass = -1, parcelId = -1;
	int parcelNumber = -1; //this is a debug number for model crop rotation validation - comparing to empirical data
	boolean hasIrrigationInf = false; //true if this parcel is equipped with irrigation infrastructure 
	
	List<Pixel> parcelPixels;
	Geometry parcelGeom;
	double rainThickness = 0 ;
	SoilType.Type soilType = SoilType.Type.INAPPROPRIATE_SOIL; //default value
	boolean isPotentiallyIrrigated = false; //true if the parcel is within a threshold vicinity from irrigation infrastructure
	boolean isReclaimedWaterIrrigation = false; //if parcel is irrigated then there are several potential water sources: reclaimed water and fresh water.
	//If reclaimed water - then this indicator is true, otherwise false (fresh water, or in the case this parcel is not irrigated).
	boolean isIrrigatedThisCycle = false;
	
	static double cubicMeterPerDunam = 500; //each dunam of agricultural land needs 500 m^3/y
	static final float parcelInitialSOM = 43; // t/ha
	static final float SOMCultivationThreshold = 25; // t/ha
	static final float SOMFallowThreshold = 18;  // t/ha
	static final double increaseAnnualFractionCMPD = 0.0033; //in case of climate change scenario - this is the annual increase ratio in agricultural water demand (0.33%)
	static final double grainToStubbleRatio = 0.15;
	static final double grainToStrawLowRainRatio = 0.75;
	
	static final int rainAmountForGrainStraw1To1Ratio = 300; //above 300 mm of rain there would be a 1:1 ratio of grain:straw weight
	
	static final Crop wheatCrop = new Crop(Crop.Type.WHEAT);
	static final Crop potatoCrop = new Crop(Crop.Type.POTATO);
	static final Crop vegCrop = new Crop(Crop.Type.VEG);
	static final Crop legumeCrop = new Crop(Crop.Type.LEGUME);
	static final Crop citrusCrop = new Crop(Crop.Type.CITRUS);
	static final Crop orchardCrop = new Crop(Crop.Type.ORCHARD);
	static final Crop fallow = new Crop(Crop.Type.FALLOW);
	
	static final boolean allParcelsConnected2IrrigatioScenario = false;
	static final boolean noParcelsConnected2IrrigatioScenario = false;
	
	//float distanceFromSettlement; //in rings (currently not implemented)
	
//	public AgriculturalLandParcel(Settlement mySettlement, List<Pixel> pixList, Geometry geom) {
//		settlement = mySettlement;
//		status = AgriculturalLandParcel.Status.SETTLEMENT_CLAIMED;//by Default a parcel belongs to a Settlement
//		parcelPixels = new ArrayList<>(pixList);
//		parcelGeom = geom;
//		
//		SOM = parcelInitialSOM;
//		cycleCount = 0;
//		currentCrop = new Crop(Crop.Type.COTTON);
//		nextCrop = new Crop(Crop.Type.CEREAL);
//		
//		// insert the parcel into the context and geography
//		Context context = ContextUtils.getContext(pixList.get(0));
//		Geography geography = (Geography) context.getProjection("Geography");
//		context.add(this);
//		geography.move(this, parcelGeom);
//	}
	public AgriculturalLandParcel(Settlement mySettlement, List<Pixel> pixList, Geometry geom, double myArea, Context context) {
		settlement = mySettlement;
		status = AgriculturalLandParcel.Status.SETTLEMENT_CLAIMED;//by Default a parcel belongs to a Settlement
		if(pixList==null){
			parcelPixels = new ArrayList<>(); //pre-existing parcels don't have pixels information
		}else{
			parcelPixels = new ArrayList<>(pixList);
		}
		parcelGeom = geom;
		area = myArea;
		
		SOM = parcelInitialSOM;
		initializeDefaultParams();
				
		settlement.currentAgriArea+=area;
		++settlement.numParcels;
		Settlement.totalAgLandInStudyArea+=area;
		
		// insert the parcel into the context and geography
		Geography geography = (Geography) context.getProjection("Geography");
		context.add(this);
		geography.move(this, parcelGeom);
	}
	
//	public AgriculturalLandParcel(Settlement mySettlement, List<Pixel> pixList, Geometry geom, Context context) {
//		settlement = mySettlement;
//		status = AgriculturalLandParcel.Status.SETTLEMENT_CLAIMED;//by Default a parcel belongs to a Settlement
//		parcelPixels = new ArrayList<>(pixList);
//		parcelGeom = geom;
//		
//		SOM = parcelInitialSOM;
//		cycleCount = 0;
//		currentCrop = new Crop(Crop.Type.COTTON);
//		nextCrop = new Crop(Crop.Type.CEREAL);
//		
//		if(!mySettlement.isFutureSettlement()){ // we want to add parcels to context only for existing Settlements
//			// insert the parcel into the context and geography
//			Geography geography = (Geography) context.getProjection("Geography");
//			context.add(this);
//			geography.move(this, parcelGeom);
//		}
//	}
	
	
	AgriculturalLandParcel(AgriculturalLandParcel parcel, Settlement mySettlement, Context context) {
		settlement = mySettlement;
		status = parcel.getStatus();
		parcelPixels = parcel.parcelPixels;
		parcelGeom = parcel.parcelGeom;
		
		SOM = parcel.getSOM();
		initializeDefaultParams();
		
		// insert the parcel into the context and geography
		Geography geography = (Geography) context.getProjection("Geography");
		context.add(this);
		geography.move(this, parcelGeom);
	}


	public AgriculturalLandParcel(AgriculturalLandParcel parcel, Settlement settlement2) {
		settlement = settlement2;
		status = parcel.getStatus();
		parcelPixels = parcel.parcelPixels;
		parcelGeom = parcel.parcelGeom;
		
		SOM = parcel.getSOM();
		initializeDefaultParams();
	}


	Geometry getParcelGeom() {
		return parcelGeom;
	}

	public double getSOM() {
		return SOM;
	}

	void setSOM(double sOM) {
		SOM = sOM;
	}

	double calculateEndOfYearSOM(){
		if (status == Status.CULTIVATED){
			if(cycleCount == 0){
				SOM-=2.38;
			}else{
				SOM-=1.19;
			}
		}else{
			if (status == Status.FALLOW){
				SOM+=0.963;
				if(SOM > parcelInitialSOM){
					SOM = parcelInitialSOM;  //parcel can't have SOM higher than parcelInitialSOM
				}
			}
		}
		return SOM;
	}
	
	public Boolean cultivateNextCycle(){
		if (SOM > SOMCultivationThreshold
				&& (status == Status.CULTIVATED || status == Status.FALLOW)) {
			return true;
		}
		return false;
	}
	private int cropToInt(Crop myCrop){
		//give values to crops according to excel sheet
		switch(myCrop.cropType){
		//WHEAT
		case WHEAT:
			return 0;
		//LEGUME
		case LEGUME:
			return 2;
		//POTATO
		case POTATO:
			return 1;
		//VEG
		case VEG:
			return 3;
		//CITRUS and ORCHARD
		case CITRUS:
		case ORCHARD:
			Settlement.logger.log(Level.WARNING, "cropToInt: Improper crop type for crop rotation cycle");
			return 0;
		//FALLOW
		case FALLOW:
			return 4;
		default:
			return 0;
		
		}
//		return myCrop.cropType.ordinal();
	}
	
	private Crop intToCrop(int myInt){
		switch(myInt){
		//WHEAT
		case 0:
			return wheatCrop;
		//POTATO
		case 1:
			return potatoCrop;
		//LEGUME
		case 2:
			return legumeCrop;
		//VEG
		case 3:
			return vegCrop;
		//FALLOW
		case 4:
			return fallow;
		default:
			Settlement.logger.log(Level.WARNING, "intToCrop: Improper crop type number");
			return wheatCrop;
		
		}
	}
		
	Crop determineCurrentCrop(){
		if(currentCrop == citrusCrop || currentCrop == orchardCrop)//these crops don't change
			return currentCrop;
		Crop myCrop = null;
		boolean potatoCropped = false;
		Random rand = new Random();
		double guess = rand.nextDouble();
		if(hasIrrigationInf){
			if((prev2YearCrop !=null && prevYearCrop !=null) && (prev2YearCrop.cropType == Crop.Type.POTATO || prev2YearCrop.cropType == Crop.Type.VEG) &&
					(prevYearCrop.cropType == Crop.Type.POTATO || prevYearCrop.cropType == Crop.Type.VEG)){
				//if last two crops where a combination of irrigated vegetables and/or potatoes - next crop should be wheat
				return wheatCrop;
			}
			//we want to have a potato crop once every 5 years - therefore this rule
			if(prev4YearCrop !=null && prev3YearCrop !=null && prev2YearCrop !=null && prevYearCrop !=null){
				if(prev4YearCrop.cropType != Crop.Type.POTATO && prev3YearCrop.cropType != Crop.Type.POTATO 
						&& prev2YearCrop.cropType != Crop.Type.POTATO && prevYearCrop.cropType != Crop.Type.POTATO){
					return potatoCrop;
				}else{//potato was already cropped during the past 4 years - can't have potato more than once every 5 years
					potatoCropped = true;
				}
			}
			if(prev2YearCrop !=null && prevYearCrop !=null){
				int prev2Y = cropToInt(prev2YearCrop);
				int prev1Y = cropToInt(prevYearCrop);
				if(IrrigationManager.cropProb[prev2Y][prev1Y][0] == 0){
					//such a combination of prev2Y and prev1Y has zero probability - we  choose Veg as next crop - since all zero probability 
					//combination are combinations of legume and fallow in the past 2 years
					return vegCrop;
				}
				for(int i=0; i<5; i++){
					if(guess <= IrrigationManager.cropProb[prev2Y][prev1Y][i]){
						myCrop = intToCrop(i);
//						if ((myCrop.cropType == Crop.Type.FALLOW || myCrop.cropType == Crop.Type.LEGUME) && prevYearCrop.cropType == Crop.Type.LEGUME)
//							return wheatCrop;
//						if ((myCrop.cropType == Crop.Type.FALLOW || myCrop.cropType == Crop.Type.LEGUME) && prevYearCrop.cropType == Crop.Type.FALLOW)
//							return vegCrop;					
						if(myCrop.cropType == Crop.Type.POTATO && (potatoCropped == true || prevYearCrop.cropType == Crop.Type.POTATO)){
							//potato was "chosen", but potato can't be cropped this coming year due to crop rotation rules, instead we choose the crop with highest probability
							myCrop = findHighestProbCrop(prev2Y, prev1Y);
							//if potato has highest probability for next crop (which is highly unlikely) - we choose second in line from wheat or other veg
							if(myCrop.cropType == Crop.Type.POTATO){
								if(IrrigationManager.cropProb[prev2Y][prev1Y][cropToInt(wheatCrop)]> IrrigationManager.cropProb[prev2Y][prev1Y][cropToInt(vegCrop)]){
									return wheatCrop;
								}
								return vegCrop;
							}
						}		
						return myCrop;
					}
				}
				Settlement.logger.log(Level.WARNING, "determineCurrentCrop: probability table failure");
				return wheatCrop;
			}else{
				Settlement.logger.log(Level.WARNING, "Missing data regarding previous 2 years crop rotation cycle");
				if(guess <=0.5)
					return wheatCrop;
				return vegCrop;
			}		
		}
		else{//parcel doesn't have irrigation 
			//there is a probability that once every 7 years the parcel is in fallow 
			if(guess <= 0.14)
				return fallow;
			if (prev2YearCrop != null && prevYearCrop != null) {
				if(prev2YearCrop.cropType == Crop.Type.WHEAT && prevYearCrop.cropType == Crop.Type.WHEAT){
//					if(guess <=0.85)
						return legumeCrop;
//					return fallow;
				}
				return wheatCrop;
			}else{
				Settlement.logger.log(Level.WARNING, "Missing data regarding previous 2 years crop rotation cycle");
				return wheatCrop;
			}	
		}
	}
	
//	Crop determineCurrentCrop(){
//		Crop myCrop = null;
//		if(hasIrrigationInf){
//			switch (cycleCount) {
//			case 0:
//				myCrop = potatoCrop;
//				break;
//			case 1:
//				myCrop = wheatCrop;
//				break;
//			case 2:
//				myCrop = vegCrop;
//				break;
//			case 3:
//				myCrop = wheatCrop;
//				break;
//			case 4:
//				myCrop = wheatCrop;
//				break;
//			default:
//				myCrop = wheatCrop;
//				System.out.println("Error in cycleCount - illegal value of: "
//						+ cycleCount);
//				break;
//			
//			}
//		}
//		else{
//			switch (cycleCount) {
//			case 0:
//				myCrop = wheatCrop;
//				break;
//			case 1:
//				myCrop = wheatCrop;
//				break;
//			case 2:
//				myCrop = legumeCrop;
//				break;
//			default:
//				myCrop = wheatCrop;
//				System.out.println("Error in cycleCount - illegal value of: "
//						+ cycleCount);
//				break;
//			}
//		
//		}
//		return myCrop;
//	}
	
	
	private Crop findHighestProbCrop(int prev2y, int prev1y) {
		double currentProb = IrrigationManager.cropProb[prev2y][prev1y][0];
		double highestProb = IrrigationManager.cropProb[prev2y][prev1y][0];
		int highestProbIndex = 0;
		for(int i=1; i<5; i++){
			currentProb = IrrigationManager.cropProb[prev2y][prev1y][i] - IrrigationManager.cropProb[prev2y][prev1y][i-1];
			if(currentProb > highestProb){
				highestProb = currentProb;
				highestProbIndex = i;
			}
		}
//		if(highestProbIndex == -1)
//			return wheatCrop;
		return intToCrop(highestProbIndex);
	}

	//For fields that have already been cultivated during initialization
	void setInitialActiveSOM(){
		SOM = parcelInitialSOM - (RandomHelper.nextIntFromTo(0, 11)*1.586); 
	}
	
	//For fields that have already been in fallow during initialization
	void setInitialFallowSOM(){
		SOM = SOMFallowThreshold + (RandomHelper.nextIntFromTo(0, 17)*0.963); //fields that have already been in fallow during initialization
	}

	
	void setStatus(Status myStatus){
		
		this.status = myStatus;
		if(getOwner()==null)
			return;
		if(myStatus== Status.CULTIVATED){
			if (!getOwner().currentCultivatedParcels.contains(this))
				getOwner().currentCultivatedParcels.add(this);
			return;
		}
		else{
			if(myStatus== Status.FALLOW)
				getOwner().currentCultivatedParcels.remove(this);
			return;
		}
	}
	
	public Status getStatus(){
		return status;
	}
	
	public String getStatusName(){
		return status.toString();
	}
	
	public FarmerAgent getOwner() {
		return owner;
	}

	void setOwner(FarmerAgent owner) {
		this.owner = owner;
	}

	public Crop getCurrentCrop() {
		return currentCrop;
	}

	Crop setCurrentCrop(Crop myCurrentCrop) {
		currentCrop = myCurrentCrop;
		return currentCrop;
	}

		void setCycleCount(int i) {
		cycleCount = i;
	}


	void advanceCycleCount() {
		if(hasIrrigationInf){
			cycleCount = (cycleCount +1) % 5;
		}
		else{
			cycleCount = (cycleCount +1) % 3;
		}
	}

	public double getArea() {
		return area;
	}
	
	//in order to calculate total area in fallow - within the model
	public double getFallowArea(){
		if(this.status == Status.FALLOW){
			return this.area;
		}
		return 0;
	}
	//in order to calculate total irrigated area per cycle - within the model
	public double getIrrigatedArea(){
		if(this.isIrrigatedThisCycle == true){
			return this.area;
		}
		return 0;
	}
	
	public double getCultivatedArea(){
		if(this.status == Status.CULTIVATED){
			return this.area;
		}
		return 0;
	}
	
	void setArea(double area) {
		this.area = area;
	}

	public String getSettlementName(){
		return settlement.getName();
	}
	
	public long getSettlementID(){
		return settlement.getID();
	}

	public double getRainThickness() {
		return rainThickness;
	}

	void setRainThickness(double rainThickness) {
		this.rainThickness = rainThickness;
	}

	void setIsPotentiallyIrrigated(boolean b) {
		isPotentiallyIrrigated = b;
	}

	public boolean isPotentiallyIrrigated() {
		return isPotentiallyIrrigated;
	}

	public boolean isReclaimedWaterIrrigation() {
		return isReclaimedWaterIrrigation;
	}

	void setReclaimedWaterIrrigation(boolean isReclaimedWaterIrrigation) {
		this.isReclaimedWaterIrrigation = isReclaimedWaterIrrigation;
	}

	public SoilType.Type getSoilType() {
		return soilType;
	}
	
	public String getSoilTypeName(){
		return soilType.toString();
	}

	void setSoilType(SoilType.Type soil) {
		this.soilType = soil;
	}

	public boolean isIrrigatedThisCycle() {
		return isIrrigatedThisCycle;
	}

	void setIrrigatedThisCycle(boolean isIrrigatedThisCycle) {
		this.isIrrigatedThisCycle = isIrrigatedThisCycle;
	}
	
	Settlement getSettlement() {
		return settlement;
	}
	
	public double getCurrentWaterDemand(){
//		return (area/1000) * AgriculturalLandParcel.cubicMeterPerDunam;
		return getCurrentCrop().getCropWaterDemand() * (area/1000);
	}
	double getGenralWaterDemand(){
		if(hasIrrigationInf)
//			return (area/1000) * AgriculturalLandParcel.cubicMeterPerDunam;
			return (area/1000) * potatoCrop.getCropWaterDemand();
		return 0;
	}
	
	void setStatusAccordingToRainOnly(){
//		if(getRainThickness() < Settlement.minRainThicknessForRainfedAg){//according to farmers - they will grow wheat even if precipitation is lower than
//			//what is perceived as minimum threshold for rain-fed
//			setStatus(Status.FALLOW);
//			getOwner().currentCultivatedParcels.remove(this);
//			return;
//		}
		setIrrigatedThisCycle(false);
//		setNextCrop(determineNextCrop());

		//choose a random double between 1 and 10
		double frequency =  RandomHelper.nextDoubleFromTo(0, 10);
		
		//15% chance this field will be in fallow next year - regardless rain amounts
//		if(frequency > 8.5){
//			setStatus(Status.FALLOW);
//			setCurrentCrop(new Crop(Crop.Type.FALLOW));
////			updatePrevYearsCrops();
//			return;
//		}
		if(!hasIrrigationInf || getCurrentCrop().getCropWaterDemand()==0){//current crop doesn't require irrigation
			if(getCurrentCrop().cropType == Crop.Type.FALLOW){
				setStatus(Status.FALLOW);
			}else{
				setStatus(Status.CULTIVATED);
			}
//			updatePrevYearsCrops();
//			setCurrentCrop(myNextCrop);
//			advanceCycleCount();
			return;
		}
		//parcel hasIrrigationInf and next crop requires irrigation
		else{
			//if parcel hasIrrigationInf and next crop requires irrigation - chances are higher that this parcel will be in fallow this cycle
			//TODO - decide about this FALLOW assignment
//			if(frequency > 8.5){
//				setStatus(Status.FALLOW);
//				setCurrentCrop(fallow); 
////				updatePrevYearsCrops();
//				return;
//			}
			//parcel is cultivated with wheat or legume - no irrigation
			setStatus(Status.CULTIVATED);
			if(prev2YearCrop.cropType == Crop.Type.WHEAT && prevYearCrop.cropType == Crop.Type.WHEAT)
				setCurrentCrop(legumeCrop);
			setCurrentCrop(wheatCrop);
//			updatePrevYearsCrops();
			return;	
		}
	}
	
	//used in climate change scenario
	static void setcCubicMeterPerDunamWaterDemand(){
		cubicMeterPerDunam += cubicMeterPerDunam*increaseAnnualFractionCMPD;
	}
	//used in climate change scenario
	void updateAnnualRainAmountClimateChange(){
		if(getRainThickness() <= 0){
			setRainThickness(this.getSettlement().getRainAnnualAmount());
		}
		setRainThickness(rainThickness* IrrigationManager.annualPrecipitationFraction);
	}

	//the owner settlement's ID - currently it is not implemented
	void setSettID(int mySettId) {
		settId = mySettId;
	}

	void setIrrigation(int myIrrigationScheme) {
		irrigationScheme = myIrrigationScheme;
		
	}

	void setCropType(int myCropType) {
		initialCropType = myCropType;
		
	}

	void setCropClass(int myCropClass) {
		cropClass = myCropClass;
		
	}
	
	private void initializeDefaultParams(){
		cycleCount = 0;
		currentCrop = wheatCrop;
	}
	
	void initializeParcel() {
		determineIrrigation();
		if(hasIrrigationInf){//irrigated agriculture crop cycle
			//update settlement's irrigated land and total irrigated land in study area
			settlement.irrigatedLand += getArea();
			Settlement.totalIrrigatedAgLandInStudyArea += getArea();
			switch(cropClass){
				case 1://field crop
				case 3://vegetable - either POTATO or VEG
					double frequency = RandomHelper.nextDoubleFromTo(1, 10);
					if (initialCropType == 1 || initialCropType == 5) {//wheat or barley - irrigated crop cycle - could be second, fourth or fifth year out of 5
						currentCrop = wheatCrop;
						// 33% chance second year in cycle
						if (frequency <= 3.33) {							
							prevYearCrop = potatoCrop;
							prev2YearCrop = wheatCrop;
							cycleCount = 1;
							break;
						}
						// 33% chance fourth year in cycle
						if (frequency <= 6.67) {
							prevYearCrop = vegCrop;
							prev2YearCrop = wheatCrop;
							cycleCount = 3;
							break;
						}
						// 33% fifth year in cycle
						prevYearCrop = wheatCrop;
						prev2YearCrop = vegCrop;
						cycleCount = 4;
						break;
						}
					else{//irrigated crop cycle - treated as other veg - third year out of 5
						if(initialCropType == 2 || initialCropType == 3){//potatoes
							currentCrop = potatoCrop;
							prevYearCrop = wheatCrop;
							prev2YearCrop = wheatCrop;
							cycleCount = 0;
							break;
						}else{//other veg
							if (frequency <= 6.5) {
								currentCrop = vegCrop;
								prevYearCrop = wheatCrop;
								prev2YearCrop = potatoCrop;
								cycleCount = 2;
								break;
							}
							else{
								currentCrop = wheatCrop;
								prevYearCrop = potatoCrop;
								prev2YearCrop = wheatCrop;
								cycleCount = 1;
								break;
							}
						}
					}
				case 2://Citrus - no cycles here - perennial tree
					currentCrop = citrusCrop;
					prevYearCrop = citrusCrop;
					prev2YearCrop = citrusCrop;
					break;
				case 4://Orchard - no cycles here - perennial tree
					currentCrop = orchardCrop;
					prevYearCrop = orchardCrop;
					prev2YearCrop = orchardCrop;
					break;
				case 5://not cultivated this cycle - fallow
				default:
					currentCrop = fallow;
					prevYearCrop = wheatCrop;
					prev2YearCrop = vegCrop;
					cycleCount = 4;
					break;
			}
		}else{//rainfed agriculture crop cycle
			if(initialCropType == 1){//Wheat - rainfed crop cycle - first year out of 3
				currentCrop = wheatCrop;
				prevYearCrop = legumeCrop;
				prev2YearCrop = wheatCrop;
				cycleCount = 0;
			}
			else{
				currentCrop = legumeCrop;
				prevYearCrop = wheatCrop;
				prev2YearCrop = wheatCrop;
				cycleCount = 2;
			}
			
		}
		
	}

//	void initializeParcel() {
//		determineIrrigation();
//		if(hasIrrigationInf){//irrigated agriculture crop cycle
//			switch(cropClass){
//				case 1://field crop
//				case 3://vegetable - either POTATO or VEG
//					double frequency = RandomHelper.nextDoubleFromTo(1, 10);
//					if (initialCropType == 1 || initialCropType == 5) {//wheat or barley - irrigated crop cycle - could be second, fourth or fifth year out of 5
//						currentCrop = wheatCrop;
//						// 33% chance second year in cycle
//						if (frequency <= 3.33) {
//							nextCrop = vegCrop;
//							cycleCount = 1;
//							break;
//						}
//						// 33% chance fourth year in cycle
//						if (frequency <= 6.67) {
//							nextCrop = wheatCrop;
//							cycleCount = 3;
//							break;
//						}
//						// 33% fifth year in cycle
//						nextCrop = potatoCrop;
//						cycleCount = 4;
//						break;
//						}
//					else{//irrigated crop cycle - treated as other veg - third year out of 5
//						if(initialCropType == 2 || initialCropType == 3){//potatoes
//							currentCrop = potatoCrop;
//							nextCrop = wheatCrop;
//							cycleCount = 0;
//							break;
//						}else{//other veg
//							if (frequency <= 6.5) {
//								currentCrop = vegCrop;
//								nextCrop = wheatCrop;
//								cycleCount = 2;
//								break;
//							}
//							else{
//								currentCrop = wheatCrop;
//								nextCrop = vegCrop;
//								cycleCount = 1;
//								break;
//							}
//						}
//					}
//				case 2://Citrus - no cycles here - perennial tree
//					currentCrop = citrusCrop;
//					nextCrop = citrusCrop;
//					break;
//				case 4://Orchard - no cycles here - perennial tree
//					currentCrop = orchardCrop;
//					nextCrop = orchardCrop;
//					break;
//				case 5://not cultivated this cycle - fallow
//					currentCrop = fallow;
//					nextCrop = potatoCrop;
//					cycleCount = 4;
//					break;
//				default:
//					currentCrop = fallow;
//					nextCrop = potatoCrop;
//					cycleCount = 4;
//					break;
//			}
//		}else{//rainfed agriculture crop cycle
//			if(initialCropType == 1){//Wheat - rainfed crop cycle - first year out of 3
//				currentCrop = wheatCrop;
//				nextCrop = wheatCrop;
//				cycleCount = 0;
//			}
//			else{
//				currentCrop = legumeCrop;
//				nextCrop = wheatCrop;
//				cycleCount = 2;
//			}
//			
//		}
//		
//	}
	
	//determine if a parcel is connected to irrigation infrastructure
	private void determineIrrigation(){
		if(allParcelsConnected2IrrigatioScenario){
			setHasIrrigationInf(true);
			return;
		}
		if(noParcelsConnected2IrrigatioScenario){
			setHasIrrigationInf(false);
			return;
		}
			
		if((irrigationScheme == 1 && cropClass == 1) ||  (cropClass == 5 && (irrigationScheme == 0 || irrigationScheme == 1) ) ){
			//field crop and marked as non irrigated this cycle or fields that are marked as non-cultivated this cycle
			//randomly select 44% of currently non-irrigated parcels to be without irrigation infrastructure, while the rest have infrastructure
//			double frequency =  RandomHelper.nextDoubleFromTo(1, 10);
//			
//			//44% chance this field has no irrigation infrastructure
//			if(frequency > 5.6){
//				setHasIrrigationInf(false);
//				return;
//			}	
			setHasIrrigationInf(false);
			return;
		}
		setHasIrrigationInf(true);
	}

	int getInitialCropType() {
		return initialCropType;
	}

	int getIrrigationScheme() {
		return irrigationScheme;
	}

	public int getParcelId() {
		return parcelId;
	}

	void setParcelId(int parcelId) {
		this.parcelId = parcelId;
	}

	public int getParcelNumber() {
		return parcelNumber;
	}

	void setParcelNumber(int parcelNumber) {
		this.parcelNumber = parcelNumber;
	}

	int getSettId() {
		return settId;
	}

	int getCropClass() {
		return cropClass;
	}
	
	public String getCurrentCropName(){
		return currentCrop.cropType.toString();
	}
	
	public boolean isHasIrrigationInf() {
		return hasIrrigationInf;
	}

	void setHasIrrigationInf(boolean hasIrrigationInf) {
		this.hasIrrigationInf = hasIrrigationInf;
	}

	Crop getPrevYearCrop() {
		return prevYearCrop;
	}

	Crop getPrev2YearCrop() {
		return prev2YearCrop;
	}
	
	public String getPrevYearCropName() {
		if(prevYearCrop != null)
			return prevYearCrop.cropType.toString();
		return null;
	}

	public String getPrev2YearCropName() {
		if(prev2YearCrop != null)
			return prev2YearCrop.cropType.toString();
		return null;
	}

	void setPrevYearCrop(Crop prevYearCrop) {
		this.prevYearCrop = prevYearCrop;
	}

	void setPrev2YearCrop(Crop prev2YearCrop) {
		this.prev2YearCrop = prev2YearCrop;
	}

	void calculateWheatYield() {
		double rainAmount = rainThickness; 
		
		if(getCurrentCrop().cropType != Crop.Type.WHEAT){
			setCurrentWheatYieldForFarmer(0);
			setCurrentWheatYieldForGrazing(0);
			setCurrentStrawWheatYield(0);
			return;
		}
				
		double wheatYield = 0;
		boolean irrigatedLastYear = false;
		boolean irrigated2YearsAgo = false;
		//TODO - also take into account current year's dynamic precipitation
		if (prevYearCrop != null){
			switch (prevYearCrop.cropType){
			case WHEAT: //non irrigated crop last year
			case LEGUME:
			case FALLOW:
				if(prev2YearCrop != null){
					if(prev2YearCrop.cropType == Crop.Type.POTATO || prev2YearCrop.cropType == Crop.Type.VEG){
						irrigated2YearsAgo = true;
						break;
					}
					break;
				}
				break;
			case POTATO:
			case VEG:
				irrigatedLastYear = true;
				break;
			case CITRUS:
			case ORCHARD:
				//error message
				Settlement.logger.log(Level.INFO, "Improper Wheat crop type in a field that has perennial tree crop");
				setCurrentWheatYieldForFarmer(0);
				setCurrentWheatYieldForGrazing(0);
				setCurrentStrawWheatYield(0);
				return;
			default:
				break;
			}
			
		}
		determineWheatYield(rainAmount, irrigatedLastYear, irrigated2YearsAgo);
		return;
		
		//if rain amount is below the irrigated minimal rain threshold, or if this parcel wasn't irrigated last year and annual rain amount is 
		//below the rain-fed minimal threshold - there is no grain yield for the farmer 
//		if((rainAmount < IrrigationManager.minimalRainAmountForWheatYieldinPrev1yIrrigatedField) || 
//				(irrigatedLastYear == false &&  irrigated2YearsAgo == false && rainAmount < IrrigationManager.minimalRainAmountForWheatYieldinRainfedField) || 
//				(irrigatedLastYear == false &&  irrigated2YearsAgo == true && rainAmount < IrrigationManager.minimalRainAmountForWheatYieldinPrev2yIrrigatedField)){
//				wheatYield = 0;
//				setCurrentWheatYieldForFarmer(0);
//				//calculate wheat yield for grazing only
//				double wheatYieldGrazing = determineWheatYield(rainAmount, irrigatedLastYear, irrigated2YearsAgo);
//				setCurrentWheatYieldForGrazing(wheatYieldGrazing);
//				return;
//			}	
//		
//		wheatYield = determineWheatYield(rainAmount, irrigatedLastYear, irrigated2YearsAgo);
//		setCurrentWheatYieldForFarmer(wheatYield);
//		setCurrentWheatYieldForGrazing(wheatYield*grainToStubbleRatio);
//		return;
	}
	
			
	//return the wheat yield in tons
	private double determineWheatYield(double rainAmount, boolean irrigatedLastYear, boolean irrigated2YearsAgo){
		double wheatGrainYield;
		if (irrigatedLastYear) {
			wheatGrainYield = 0.85 * rainAmount + 276.3; // in kg per dunam
		} else {
			if (irrigated2YearsAgo) {
				wheatGrainYield = (0.92 * rainAmount + 11.2) * 1.25;
			} else {
				wheatGrainYield = 0.92 * rainAmount + 11.2;
			}
		}
		wheatGrainYield = (wheatGrainYield * (area/1000))/1000; //wheat yield in tons
		
		setCurrentWheatYieldForFarmer(wheatGrainYield); 
		setCurrentStrawWheatYield(wheatGrainYield* grainToStrawLowRainRatio);
		setCurrentWheatYieldForGrazing(wheatGrainYield*grainToStubbleRatio);
	
		if((rainAmount < IrrigationManager.minimalRainAmountForWheatYieldinPrev1yIrrigatedField) || 
				(irrigatedLastYear == false &&  irrigated2YearsAgo == false && rainAmount < IrrigationManager.minimalRainAmountForWheatYieldinRainfedField) || 
				(irrigatedLastYear == false &&  irrigated2YearsAgo == true && rainAmount < IrrigationManager.minimalRainAmountForWheatYieldinPrev2yIrrigatedField)){
				
				setCurrentWheatYieldForFarmer(0); //no grains below rain amount threshold 
				setCurrentStrawWheatYield(wheatGrainYield* grainToStrawLowRainRatio*0.5);
				setCurrentWheatYieldForGrazing(wheatGrainYield*grainToStubbleRatio*0.5);
		}
				
		if(rainAmount > rainAmountForGrainStraw1To1Ratio){
			setCurrentStrawWheatYield(wheatGrainYield);
		}
		return wheatGrainYield;
	}
	
	//return the wheat yield in tons
//		private double determineWheatYield(double rainAmount, boolean irrigatedLastYear, boolean irrigated2YearsAgo){
//			// TODO - update formulas
//			double wheatYield;
//			if (irrigatedLastYear) {
//				wheatYield = 0.85 * rainAmount + 276.3; // in kg per dunam
//			} else {
//				if (irrigated2YearsAgo) {
//					wheatYield = (0.92 * rainAmount + 11.2) * 1.25;
//				} else {
//					wheatYield = 0.92 * rainAmount + 11.2;
//				}
//			}
//			wheatYield = (wheatYield * (area/1000))/1000;
//			return wheatYield;
//		}

	//ton per dunam
	public double getCurrentWheatYieldForFarmer() {
		return currentWheatYieldForFarmer;
	}
	
	//wheat yield in tons
	void setCurrentWheatYieldForFarmer(double currentWheatYield) {
		this.currentWheatYieldForFarmer = currentWheatYield;
	}
	
	//wheat yield in tons
	void setCurrentWheatYieldForGrazing(double currentWheatYield) {
		this.currentWheatYieldForGrazing = currentWheatYield;
	}
	
	public double getCurrentWheatYieldForGrazing() {
		return currentWheatYieldForGrazing;
	}
	

	public double getCurrentStrawWheatYield() {
		return currentStrawWheatYield;
	}
	//straw wheat yield in tons
	void setCurrentStrawWheatYield(double currentStrawWheatYield) {
		this.currentStrawWheatYield = currentStrawWheatYield;
	}

	void updatePrevYearsCrops() {
		if (prev3YearCrop != null)
			prev4YearCrop = new Crop(prev3YearCrop);
		
		if (prev2YearCrop != null)
			prev3YearCrop = new Crop(prev2YearCrop);
		
		if (prevYearCrop != null)
			// prev2YearCrop = new Crop(prevYearCrop.cropType);
			prev2YearCrop = new Crop(prevYearCrop);
		if (currentCrop != null)
			// prevYearCrop = new Crop(currentCrop.cropType);
			prevYearCrop = new Crop(currentCrop);

	}
	
//	public void setNextCrop(Crop nextCrop) {
//		this.nextCrop = nextCrop;
//	}
	
}
