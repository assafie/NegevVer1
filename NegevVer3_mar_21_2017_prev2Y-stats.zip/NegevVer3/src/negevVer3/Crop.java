package negevVer3;

public class Crop {
	
	public enum Type{
		WHEAT,//NON-IRRIGATED
		LEGUME,//pea, chick-pea, clover - NON IRRIGATED 
		POTATO,//IRRIGATED
		VEG,// carrot, ground nut (peanut), cotton, sweet potato, parsley, radish, cabbage, water-melon, herbs, garlic, onion - IRRIGATED
		CITRUS,//IRRIGATED
		ORCHARD,//IRRIGATED
		FALLOW//no cultivation
	}
	
	public Type cropType;
	

	Crop(Type crop){
		cropType = crop;
	}
	
	Crop(Crop myCrop){
		this(myCrop.getCropType());
	}

	
	Type getCropType() {
		return cropType;
	}
	//returns Crop water demand per dunam 
	int getCropWaterDemand(){
		switch (cropType.ordinal()) {
		case 0:
			return 0;
		case 1:
			return 0;
		case 2:
			return 500;
		case 3:
			return 500;
		case 4:
			return 1000;
		case 5:
			return 1000;
		case 6:
			return 0;
		default:
			return 0;
		
		}
	}
		

}
