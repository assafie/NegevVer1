package negevVer3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;

import negevVer3.Pixel.Classification;
import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunState;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.space.gis.Geography;

import com.cenqua.ant.SetLogLevel;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.MultiLineString;
import com.vividsolutions.jts.operation.distance.DistanceOp;;

public final class IrrigationManager {
	
	private static int simulationStepCount = 0;
	
	private static IrrigationManager instance;
	
	private static long annualWaterOverallQouta = 5000000; //the initial irrigation water quota for Shikma is 5 MCM/y
	private static double annualWaterAdditionalQouta = 0; // 100000; // 0; //2000000; //annual additional water quota for the study area is 2 MCM/y
	private static long currentAvailableWater;
	private final static long  waterNeededForNewSettCluster = 2000000; //7500000; //amount of irrigation water needed in order to create a new cluster of ag. settlements - 7.5 MCM/y
	public static final  double annualWaterQuotaFraction = 1.01; //0.98; //used in climate change scenario - to diminish annualWaterAdditionalQouta by 2% annually
	public static final  double annualPrecipitationFraction = 0.992; //used in climate change scenario - to diminish annual rain amount
	public static final  int ClimateChangeSimulationCountDuration = 35; //30; //110;
	
	public static int rainFedAgThreshold = 200; //the threshold for rain-fed agriculture is 200 mm/y of rain
	static final int minimalRainAmountForWheatYieldinPrev1yIrrigatedField = 150; //100; //120; // 70; //90; //120;
	static final int minimalRainAmountForWheatYieldinRainfedField = 200; //150; // 120; //150;
	static final int minimalRainAmountForWheatYieldinPrev2yIrrigatedField = 200; //150; // 105; //135;
	
////	static final  List<Double> annualRainAmountBK_reg = Arrays.asList(0.0, 498.2, 437.7, 177.3, 352.6, 362.2, 239.6, 222.7, 342.3, 398.3, 281.6, 433.6, 284.0, 194.8, 274.7, 256.1, 
////			245.9, 522.0, 281.6, 220.2, 480.4, 181.6, 245.4, 211.4, 364.5, 372.6, 293.1, 316.2, 388.1, 611.0, 343.6);
//	static final  List<Double> annualRainAmountBK_reg = Arrays.asList(0.0, 433.6, 284.0, 194.8, 274.7, 256.1, 245.9, 522.0, 281.6, 220.2, 480.4, 
//			181.6, 245.4, 211.4, 364.5, 372.6, 293.1, 316.2, 388.1, 611.0, 343.6);
////	static final  List<Double> annualRainAmountBK_CC = Arrays.asList(0.0, 224.0, 303.4, 230.3, 371.3, 505.6, 233.4, 239.2, 116.8, 307.3, 154.4, 92.0, 222.8, 381.4, 310.6,
////			245.9, 264.9, 135.0, 193.2, 323.1, 458.7, 257.0, 359.7, 244.3, 281.5, 175.0, 230.1, 268.5, 189.5, 371.0, 235.1);
//	static final  List<Double> annualRainAmountBK_CC = Arrays.asList(0.0, 222.8, 381.4, 310.6, 245.9, 264.9, 135.0, 193.2, 390.0, 323.1, 458.7,
//			257.0, 359.7, 244.3, 281.5, 175.0, 230.1, 268.5, 189.5, 371.0, 235.1);
//	
////	static final  List<Double> annualRainAmountMH_reg = Arrays.asList(0.0, 453.0, 491.0, 227.0, 357.0, 314.0, 220.0, 179.0, 278.0, 397.0, 224.0, 350.0, 257.0, 169.0, 210.8, 
////			130.8, 179.2, 341.4, 276.9, 216.8, 318.5, 155.0, 215.0, 168.0, 321.0, 350.0, 256.0, 235.0, 300.0, 384.0, 242.0);
//	static final  List<Double> annualRainAmountMH_reg = Arrays.asList(0.0, 350.0, 257.0, 169.0, 210.8, 130.8, 179.2, 341.4, 276.9, 216.8, 318.5, 
//			155.0, 215.0, 168.0, 321.0, 350.0, 256.0, 235.0, 300.0, 384.0, 242.0);
////	static final  List<Double> annualRainAmountMH_CC = Arrays.asList(0.0, 189.0, 229.0, 185.0, 259.0, 370.0, 149.0, 199.0, 85.0, 276.0, 170.0, 77.0, 
////			188.0, 351.0, 200.0, 180.0, 204.1, 113.5, 136.7, 313.5, 334.0, 176.0, 298.0, 151.3, 193.2, 140.5, 206.5, 202.4, 177.2, 285.5, 196.5);
//	static final  List<Double> annualRainAmountMH_CC = Arrays.asList(0.0, 188.0, 351.0, 200.0, 180.0, 204.1, 113.5, 136.7, 285.8, 313.5, 334.0, 
//			176.0, 298.0, 151.3, 193.2, 140.5, 206.5, 202.4, 177.2, 285.5, 196.5);

	
	
	static final  List<Integer> annualRainAmountBK_reg = Arrays.asList(0,   432,	217,	281,	312,	204,	144,	261,	240,	50,	280,	319,	314,	252,
			280,	503,	367,	537,	326,	243,	515,	249,	204,	278,	181,	443,	319,	236,	330,	324,	347,	291,	294,	184,
			255,	312,	312,	392,	333,	241,	392,	274,	172,	378,	158,	169,	90,	276,	396,	104,	318);
	
	static final  List<Integer> annualRainAmountBK_CC = Arrays.asList(0, 126,	251,	248,	312,	246,	361,	326,	97,	412,	146,	332,	262,	248,
			187,	277,	295,	294,	213,	280,	218,	308,	265,	184,	92,	88,	289,	226,	254,	131,	334,	218,	257,	200,	304,
			369,	221,	159,	279,	295,	189,	203,	157,	205,	119,	325,	212,	299,	72,	131,	210);
	
	static final  List<Integer> annualRainAmountMH_reg = Arrays.asList(0, 338, 170, 220,	244,	160,	112,	204,	188,	39,	219,	250,	246,	197,
			219,	394,	287,	420,	255,	190,	403,	195,	159,	218,	142,	347,	250,	185,	259,	253,	272,	228,	230,	144,
			199,	244,	244,	307,	261,	189,	307,	214,	135,	296,	124,	133,	70,	216,	310,	81,	249);
	
	static final  List<Integer> annualRainAmountMH_CC = Arrays.asList(0, 99, 196, 194, 244, 192, 283, 255, 76, 323,	114, 260, 205, 194,	146, 217, 230, 230,	167, 219, 170, 
			241, 207, 144, 72, 69, 226,	177, 199, 103,	261, 171, 201, 156,	238, 289, 173, 124,	218, 231, 147,	159, 122, 160,	93,	254, 166, 234, 56, 102, 164);


//	static final  List<Integer> annualRainAmount = Arrays.asList(0,300, 400, 250, 250, 250, 140, 350, 110, 200, 250, 300, 350, 100, 200, 350, 350, 350, 300, 200, 300);
//	final static int[] annualRainAmount = {0,300, 400, 250, 250, 250, 140, 350, 110, 200, 250, 300, 350, 100, 200, 350, 350, 350, 300, 200, 300}; 
	
	//a cumulative probability table to get a crop given previous 2 years crops from the inventory of crops: wheat, potato, legume, other, fallow
	//based on crop rotation frequencies 2000-2010
	static final double [][][] cropProb = new double [][][]{
		{	{0.24, 0.40, 0.63, 0.85, 1.00},    {0.61, 0.66, 0.66, 0.81, 1.00},    {0.71, 0.96, 0.96, 1.00, 1.00},   {0.41, 0.72, 0.72, 0.84, 1.00},   {0.63, 0.88, 0.92, 1.00, 1.00}, },    
		{	{0.67, 0.73, 0.73, 0.99, 1.00},    {1.00, 1.00, 1.00, 1.00, 1.00},    {0.00, 0.00, 0.00, 0.00, 0.00},   {0.45, 0.45, 0.45, 0.55, 1.00},   {0.67, 0.67, 0.67, 0.95, 1.00}, },
		{	{0.55, 0.85, 0.95, 0.95, 1.00},    {0.57, 0.57, 0.57, 0.86, 1.00},    {0.00, 0.00, 0.00, 0.00, 0.00},   {0.00, 1.00, 1.00, 1.00, 1.00},   {0.00, 0.00, 0.00, 0.00, 0.00}, },
		{	{0.24, 0.69, 0.76, 1.00, 1.00},    {0.66, 0.69, 0.69, 0.93, 1.00},    {0.00, 0.00, 0.00, 0.00, 0.00},   {0.47, 0.68, 0.68, 0.95, 1.00},   {0.63, 1.00, 1.00, 1.00, 1.00}, },
		{	{0.51, 0.89, 0.89, 1.00, 1.00},    {0.87, 0.87, 0.87, 0.93, 1.00},    {1.00, 1.00, 1.00, 1.00, 1.00},   {0.57, 0.71, 0.71, 0.71, 1.00},   {1.00, 1.00, 1.00, 1.00, 1.00}, }
	};
	//based on crop rotation frequencies 1990-2010
//	static final double [][][] cropProb = new double [][][]{
//		{	{0.17, 0.39, 0.59, 0.84, 1.00},    {0.64, 0.68, 0.69, 0.85, 1.00},    {0.77, 0.95, 0.95, 0.98, 1.00},   {0.46, 0.70, 0.74, 0.89, 1.00},   {0.68, 0.84, 0.86, 1.00, 1.00}, },    
//		{	{0.60, 0.64, 0.68, 0.95, 1.00},    {1.00, 1.00, 1.00, 1.00, 1.00},    {0.60, 0.60, 0.60, 1.00, 1.00},   {0.58, 0.58, 0.64, 0.73, 1.00},   {0.74, 0.74, 0.74, 0.96, 1.00}, },
//		{	{0.61, 0.87, 0.90, 0.97, 1.00},    {0.53, 0.53, 0.53, 0.87, 1.00},    {0.00, 0.00, 0.00, 0.00, 0.00},   {0.55, 0.64, 0.64, 0.91, 1.00},   {0.00, 0.00, 0.00, 0.00, 0.00}, },
//		{	{0.26, 0.59, 0.71, 0.98, 1.00},    {0.64, 0.67, 0.73, 0.93, 1.00},    {0.36, 0.55, 0.55, 1.00, 1.00},   {0.46, 0.72, 0.77, 0.97, 1.00},   {0.53, 0.93, 0.93, 1.00, 1.00}, },
//		{	{0.55, 0.86, 0.87, 1.00, 1.00},    {0.85, 0.85, 0.85, 0.90, 1.00},    {0.00, 0.00, 0.00, 0.00, 0.00},   {0.50, 0.64, 0.64, 0.79, 1.00},   {0.00, 0.00, 0.00, 0.00, 0.00}, }
//	};
		
	
	//The first entity on the list is the root of the irrigation system - the rest of the links are ordered according to the direction of the irrigation infrastructure
	static List<IrrigationPipeLink> IrrigationPipes = new ArrayList<>(); //list of IrrigationPipeLink
	
	
	private IrrigationManager(){
		simulationStepCount = 0;
	}
	
	public static IrrigationManager getInstance(){
		if(instance == null){
			instance = new IrrigationManager();
		}
		return instance;
	}
	
	@ScheduledMethod(start = 1, interval = 1, priority = 2)
	public void step() {
		
		simulationStepCount++;
		
		if(AgriculturalLandParcel.noParcelsConnected2IrrigatioScenario)//no irrigated fields - no water quotas
			return;
		
		currentAvailableWater = getAnnualWaterOverallQouta();
//		if(ContextCreator.isClimateChange && simulationStepCount <= ClimateChangeSimulationCountDuration){//in case we are in climate change scenario - annual additional water is diminishing and agricultural water demand increasing
//			annualWaterAdditionalQouta = annualWaterAdditionalQouta*annualWaterQuotaFraction;
//			//TODO - update this method to apply to specific crop water demand
//			AgriculturalLandParcel.setcCubicMeterPerDunamWaterDemand();
//		}
		annualWaterOverallQouta+= annualWaterAdditionalQouta; //every year (step) the water quota is increased by annualWaterAdditionalQouta 
		//only 2 settlements in study area - Bet Kama and Mishmar Hanegev
		long waterQuota = currentAvailableWater;
		double totalSettDemand = 0;
		double mh_waterDemand = 0;
		double bk_waterDemand = 0;
		Settlement mh = null;
		Settlement bk = null;
//		long settQuota = 0;
		for(Settlement sett :Settlement.settlements){
			if(sett.getID() == 395){//MH
				mh_waterDemand = sett.getCurrentCycleWaterDemand();
				mh = sett;
				
			}
			if(sett.getID() == 598){
				bk_waterDemand = sett.getCurrentCycleWaterDemand();
				bk = sett;
			}
		}
		totalSettDemand = mh_waterDemand + bk_waterDemand;
		//each settlement receives the relative ratio between total demand and total availability multiplied by its water demand
		mh.setCurrentWaterQuota((waterQuota/totalSettDemand)*mh_waterDemand);
		currentAvailableWater -= (waterQuota/totalSettDemand)*mh_waterDemand;
		bk.setCurrentWaterQuota((waterQuota/totalSettDemand)*bk_waterDemand);
		currentAvailableWater -= (waterQuota/totalSettDemand)*bk_waterDemand;	
			
//		for(Settlement sett :Settlement.settlements){
//			if(sett.getID() == 395){
//				settQuota = Math.round(waterQuota*0.66);
//				sett.setCurrentWaterQuota(settQuota);
//			}
//			if(sett.getID() == 598){
//				settQuota = Math.round(waterQuota*0.34);
//				sett.setCurrentWaterQuota(settQuota);
//			}
//			currentAvailableWater -= settQuota;
//			settQuota = 0;
//		}
		
//		for(Settlement sett :Settlement.settlements){//first we zero all settlements' water quota (from the previous step)
//			sett.setCurrentWaterQuota(0);
//		}
//		List<Settlement> randomSettList = new ArrayList<>(Settlement.settlements);//creating a random list will distribute water in a different order of settlements
//		//every cycle
//		Collections.shuffle(randomSettList);
//		
//		for (Settlement sett :randomSettList){
//			if(ContextCreator.isClimateChange  && simulationStepCount <= ClimateChangeSimulationCountDuration){
//				sett.setRainAnnualAmount(sett.getRainAnnualAmount()*annualPrecipitationFraction);
//			}
//			distributeWatertoSettlement(sett);
//			if(currentAvailableWater <= 0){
//				Settlement.logger.log(Level.INFO, "Currently not enough irrigation water available for all settlements, at timestep " + simulationStepCount);
//				return;
//			}
//			
//		}
//		if(currentAvailableWater >= waterNeededForNewSettCluster){
//			createNewCluster();
//		}
		
		Settlement.logger.log(Level.INFO, "Currently leftover available water at timestep " + simulationStepCount + " is: " + currentAvailableWater);
				
//		simulationStepCount++;
//		//reseting processedWaterDemand boolean value - for the current timestep - in order to process all links 
//		for(IrrigationPipeLink link: IrrigationManager.IrrigationPipes){
//			link.processedWaterDemand = false;
//		}
//		//go over all irrigation pipe links - for every link within IrrigationPipes (which is ordered) and calculate how much water it has available - 
//		//then distribute the water to farmers
//		currentAvailableWater = getAnnualWaterOverallQouta();
//		for(IrrigationPipeLink link: IrrigationManager.IrrigationPipes){
//			if(!link.isCurrentlyOnline){
//				if(link.onlineYear > simulationStepCount){
//					break; //since the list is ordered - if this link is not online - all subsequent descendant links are not online
//				}
//				else{
//					link.isCurrentlyOnline = true;
//					//connect the new irrigation pipeline link with new settlements
//					link.createNewSettlements(null);
//				}
//			}
//			//distribute this cycle quota amount of water
//			distributeWatertoSettlements(link);
//						
//			//go over all descending links see how much water they need and divide water accordingly
//			for(IrrigationPipeLink descendantLink: link.descendantLinks){
//				if(descendantLink.isCurrentlyOnline){
//					distributeWatertoSettlements(descendantLink);
//				}
//			}		
//		}
//		Settlement.logger.log(Level.INFO, "Currently leftover available water at timestep " + simulationStepCount + " is: " + currentAvailableWater);
//		annualWaterOverallQouta+= 2000000; //every year (step) the water quota is increased by 2 MCM
	}
	
	private static void distributeWatertoSettlement(Settlement sett){
//		double settWaterDemand = sett.getNextCycleWaterDemand();
		double settWaterDemand = sett.getCurrentCycleWaterDemand();
//		long settIrrigatedAreaWaterDemand = sett.getIrrigatedAreaWaterDemand();
		double settRainThickness = sett.getRainAnnualAmount();
		double allocatedwater;
		double waterRatio;
		if(settRainThickness >=350){
			waterRatio = 0.6;
		}else{
			if(settRainThickness >=250){
				waterRatio = 0.75;
			}
			else{
				waterRatio = 0.9;
			}
		}
//		allocatedwater = Math.min(settWaterDemand*waterRatio, settIrrigatedAreaWaterDemand*1.02);
		allocatedwater = settWaterDemand*waterRatio;
		//TODO - switch to this line when including all study area
		//for now - since only Shikma's ag. area is included in study area - we divide by constant
//		allocatedwater += annualWaterAdditionalQouta*(sett.currentAgriArea / Settlement.totalAgLandInStudyArea);
		//TODO - get rid of constant
		//currently all water addition (2MCM/yr) is divided among existing settlements - in order to allow for extar water to be allocated for new settlements
		//this formula needs to be adjusted (e.g. divide total by 2 - half for existing and half for future settlements)
		allocatedwater += annualWaterAdditionalQouta*(sett.currentAgriArea / 640000000);
		sett.setCurrentWaterQuota(allocatedwater);
		currentAvailableWater -= allocatedwater;
		
//		double settIrrigatedAreaWaterDemand = (sett.getIrrigatedAreaWaterDemand() *1.02);
//		sett.setCurrentWaterQuota(settIrrigatedAreaWaterDemand);
//		currentAvailableWater -= (settIrrigatedAreaWaterDemand);	
	}
	
//	private static void  distributeWatertoSettlements(IrrigationPipeLink link){
//		//in case the link "Was taken care of" - was processed already for water distribution to farmers within its reach - no need to do it again
//		if(link.processedWaterDemand == true)
//			return;
//		link.availableWaterAmount = currentAvailableWater;
//		long linkExtractedWaterAmount = 0;
//		for(Settlement settlement: link.irrigatedSettlements){
//			double settlementWaterDemand = settlement.getNextCycleWaterDemand();
//			if(settlementWaterDemand > currentAvailableWater){
//				//TODO - no more available water - all other settlements' parcels can't be irrigated - solve synchronization settlement updating issue
//				settlement.unmetWaterDemand = true;
//				continue; 
//			}
//			currentAvailableWater-=settlementWaterDemand;
//			linkExtractedWaterAmount += settlementWaterDemand;
//			settlement.unmetWaterDemand = false;
//		}
//		link.extractedWaterAmount = linkExtractedWaterAmount;
//		link.transferedWaterAmount = currentAvailableWater; //this is the amount of water available for descendant links
//		link.processedWaterDemand = true;
//		return;
//	}
	
	private void createNewCluster(){		
		Context context = RunState.getSafeMasterContext();
		Geography geography = (Geography) context.getProjection("Geography");
		
		long numParcels = 0;
		while(numParcels < Settlement.minNumParcelsPerSettlement){
			if(PotentialAgPixel.pixelSet.isEmpty()){
				Settlement.logger.log(Level.INFO, "No more agricultural area available");
				break;
			}
			PotentialAgPixel pixel = PotentialAgPixel.pixelSet.first();
			Pixel settPixel = new Pixel(Classification.SETTLEMENT, pixel.getGeom(), pixel.getCoord_m());
			Settlement newSettlement = new Settlement(settPixel);
			
			context.add(newSettlement);
			geography.move(newSettlement, newSettlement.getPixel().getGeom());
			numParcels = newSettlement.calculateAgriculturalCapacity(context, pixel.getOrigGeom());
			
			if(numParcels < Settlement.minNumParcelsPerSettlement){
				//remove newSettlement from pixelSet
				PotentialAgPixel.pixelSet.remove(pixel);
//				PotentialAgPixel.pixelSet.remove(PotentialAgPixel.pixelSet.first());
				//restore all other pixels that are Marked to be suitable, and restore Settlement.totalAgLandInStudyarea 
				newSettlement.erasePotentialSettlement();
				//disable potential settlement's immediate neighbors from being potential settlements 
				PotentialAgPixel.updatePixelSet(newSettlement, Math.pow((Settlement.settlementRadius/3),2));
				//remove newSettlement from context and geography
				geography.move(newSettlement, null);
				context.remove(newSettlement);
				newSettlement = null;
				Settlement.numSettlements--;
			}
			else{
				Settlement.settlements.add(newSettlement);
				//assign a farmer for the settlement
				newSettlement.assignFarmerToParcels(context);
				//update all components of pixelSet with the new settlement
				PotentialAgPixel.updatePixelSet(newSettlement, Math.pow((Settlement.settlementRadius*2),2));
				PotentialAgPixel.pixelSet.remove(pixel);
				
				//add road and irrigation infrastructure to new settlement - and update distance to road and irrigation - update pixelSet
				updateRoadAndIrrigationInfrastructure(pixel, context);
			
				
				newSettlement.setRainAnnualAmount(pixel.getRainAnnualAmount());
				//update totalIrrigated area. totalAgLandInStudyarea is updated in AgParcel's constructor
				Settlement.totalIrrigatedAgLandInStudyArea+=newSettlement.getIrrigatedLand(); 
				return;
			}	
		}
	}
	
	private void updateRoadAndIrrigationInfrastructure(PotentialAgPixel pixel, Context context){
		Geography geography = (Geography) context.getProjection("Geography");
		int roadID = pixel.getClosestRDid();
		int irrigationID = pixel.getClosestIrrid();
		Road closestRoad = Road.roadMap.get(new Integer(roadID));
		IrrigationPipeLink closestIrrPipe = IrrigationPipeLink.irrigationMap.get(new Integer(irrigationID));
		
		if(closestRoad == null || closestIrrPipe == null){
			Settlement.logger.log(Level.WARNING, "Error: could not find closest road or irrigation infrastructure to new settlement");
			return;
		}
		//add new road segment to new settlement
//		Coordinate[] roadCoords = closestRoad.getRoadLine().getCoordinates();
		Geometry roadGeomMeter = ContextCreator.convertGeometryFromWGStoCRS(closestRoad.getRoadLine(), geography);
//		Coordinate[] roadCoords = roadGeomMeter.getCoordinates();
		
		DistanceOp distOp = new DistanceOp(roadGeomMeter, pixel.origGeom);
		Coordinate[] newRoadCoord = distOp.nearestPoints();
		double dist = distOp.distance(); //debug
		Settlement.totalAddedRoadKM += dist/1000;
				
//		double distance = pixel.distToRoad;
//		Coordinate pixelCoord = pixel.getCoord_m();
//		Coordinate targetCoord = findNewLineTargetCoord(pixelCoord, roadCoords);
//		if(targetCoord==null){
//			targetCoord = roadGeomMeter.getCentroid().getCoordinate(); 
//		}
//		Coordinate[] newRoadCoord_old = new Coordinate[]{targetCoord, pixelCoord};
//		Geometry newRoadLine = new GeometryFactory().createLineString(newRoadCoord);
		Geometry newRodeMultiLineMeter = createMultiLineString(newRoadCoord);
		
		//get the WGS geometry in order to place in geography
		Geometry newRodeMultiLineWGS =ContextCreator.convertGeometryToWGS(newRodeMultiLineMeter, geography);

		Road myRoad = new Road(newRodeMultiLineWGS, newRodeMultiLineMeter.getLength(), 
				closestRoad.getRoadNum(), (Road.roadMap.size()+100));
		context.add(myRoad);
		geography.move(myRoad, newRodeMultiLineWGS);
	
		//add new pipeline segment to new settlement
//		Coordinate[] irrCoords = closestIrrPipe.getGeom().getCoordinates();
		Geometry irrGeomMeter =  ContextCreator.convertGeometryFromWGStoCRS(closestIrrPipe.getGeom(),geography);
		
		distOp = new DistanceOp(irrGeomMeter, pixel.origGeom);
		Coordinate[] newIrrCoord = distOp.nearestPoints();
		dist = distOp.distance();
		Settlement.totalAddedIrrInfraKM += dist/1000;
		
//		Coordinate[] irrCoords = irrGeomMeter.getCoordinates();
//		distance = pixel.distToIrrigation;
//		targetCoord = findNewLineTargetCoord(pixelCoord, irrCoords);
//		if(targetCoord==null){
//			targetCoord = irrGeomMeter.getCentroid().getCoordinate(); 
//		}
//		Coordinate[] newIrrCoord = new Coordinate[]{targetCoord, pixelCoord};
//		Geometry newIrrLine = new GeometryFactory().createLineString(newIrrCoord);
		Geometry newIrrMultiLineMeter = createMultiLineString(newIrrCoord);
		Geometry newIrrMultiLineWGS = ContextCreator.convertGeometryToWGS(newIrrMultiLineMeter, geography);
		
		IrrigationPipeLink myIrrLink = new IrrigationPipeLink(closestIrrPipe.isReclaimedWater(), 
			(IrrigationPipeLink.irrigationMap.size()+100), IrrigationManager.getSimulationStepCount(), newIrrMultiLineWGS, newIrrMultiLineMeter.getLength());
		context.add(myIrrLink);
		geography.move(myIrrLink, newIrrMultiLineWGS);
	
		//update components of PotentialAgPixel.pixelSet - with the new road and piping infrastructure 
		PotentialAgPixel.updatePixelSetWithNewRoadAndIrrigation(myIrrLink, myRoad, geography);
		
	}
	
	//find the coordinate with minimum distance to the pixelCoord
	private Coordinate findNewLineTargetCoord(Coordinate pixelCoord, Coordinate[] sourceCoords){
		double minDistance, tempDistance;
		minDistance = tempDistance = Integer.MAX_VALUE;
		Coordinate targetCoord = null;
		for(Coordinate coord: sourceCoords){
			if((tempDistance = coord.distance(pixelCoord))< minDistance){
				targetCoord = coord;
				minDistance = tempDistance;
			}
		}
		return targetCoord;
	}
	
	private MultiLineString createMultiLineString(Coordinate[] coords){
		LineString newRoadLineString = new GeometryFactory().createLineString(coords);
		LineString[] lineStrings = new LineString[] {newRoadLineString};
		return new GeometryFactory().createMultiLineString(lineStrings);	
	}
	
	static void createIrrigationPipesTree(Geography geography) {		
		int index = 0;
		int innerIndex = 0;
		
		//iterate over all link - starting from the root and checking for each node which are the other nodes directly connected to it
		for(IrrigationPipeLink link: IrrigationManager.IrrigationPipes){
			
			if(IrrigationPipes.size() <= (index+1))
				break;
			innerIndex = index;
			for(IrrigationPipeLink descendantLink = IrrigationPipes.get(innerIndex+1) ; IrrigationPipes.size() > (innerIndex+1) ; innerIndex++){
				descendantLink = IrrigationPipes.get(innerIndex+1);
				Geometry linkBuffer = ContextCreator.generateBuffer(geography, link.getGeom(), Settlement.pixelSize);
				if(linkBuffer.intersects(descendantLink.geom)){
					descendantLink.setParentLink(link);
					link.descendantLinks.add(descendantLink);
				}
			}	
			index++;
		}
	}
	
	static void connectSettlementToPipeline(Settlement settlement, IrrigationPipeLink link) {
		link.irrigatedSettlements.add(settlement);
		settlement.irrigatingLink = link;
	}

	static int getSimulationStepCount() {
		return simulationStepCount;
	}
	
	public static long getAnnualWaterOverallQouta(){
		return annualWaterOverallQouta; 
	}


}
